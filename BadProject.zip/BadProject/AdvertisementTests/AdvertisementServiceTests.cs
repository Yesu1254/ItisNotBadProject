using Adv;
using System.Configuration;
using ThirdParty;

namespace AdvertisementTests
{
	[TestFixture]
	public class AdvertisementServiceTests
	{
		private AdvertisementService _service;

		[SetUp]
		public void Setup()
		{
			ConfigurationManager.AppSettings["RetryCount"] = "0";
			_service = new AdvertisementService();
		}

		[Test]
		public void Get_Adv_From_Cache()
		{
			// Arrange
			var id = "1";
			var advert = new Advertisement { WebId = id, Name = "Test Cache", Description = "Good Project" };
			_service.SetAdvertisementCache(id, advert);

			// Act
			var result = _service.GetAdvertisement(id);

			// Assert
			Assert.That(result, Is.EqualTo(advert));
		}

		[Test]
		public void Get_Adv_From_HttpProvider()
		{
			// Arrange
			var id = "2";
			ConfigurationManager.AppSettings["RetryCount"] = "3";
			var provider = new NoSqlAdvProvider();
			var advert = provider.GetAdv(id);

			// Act
			var result = _service.GetAdvertisement(id);

			// Assert
			Assert.That(result, Is.EqualTo(advert));
		}

		[Test]
		public void Get_Adv_From_BackupProvider()
		{
			// Arrange
			var id = "3";
			var advert = SQLAdvProvider.GetAdv(id);

			// Act
			var result = _service.GetAdvertisement(id);

			// Assert
			Assert.That(result, Is.EqualTo(advert));
		}
	}
}