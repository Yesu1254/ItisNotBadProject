﻿// Third Party classes / components
// READ ONLY
// Modification is not allowed