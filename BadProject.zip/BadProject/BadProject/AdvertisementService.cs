﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Caching;
using System.Threading;
using ThirdParty;

namespace Adv
{
	public class AdvertisementService
	{
		private readonly MemoryCache _cache = new MemoryCache("Test_Adv");
		private readonly Queue<DateTime> _errors = new Queue<DateTime>();
		private readonly object _lockObj = new object();

        public Advertisement GetAdvertisement(string id)
		{
			Advertisement advertisement = null;

			lock (_lockObj)
			{
				advertisement = TryGetAdvertisementFromCache(id) ?? TryGetAdvertisementFromHttpProvider(id);

				if (advertisement == null)
				{
					advertisement = TryGetAdvertisementFromBackupProvider(id);
				}
			}

			return advertisement;
		}

		public void SetAdvertisementCache(string id, Advertisement advertisement)
		{
			_cache.Set($"AdvKey_{id}", advertisement, DateTimeOffset.Now.AddMinutes(5));
		}

		private Advertisement TryGetAdvertisementFromCache(string id)
		{
			return (Advertisement)_cache.Get($"AdvKey_{id}");
		}

		private Advertisement TryGetAdvertisementFromHttpProvider(string id)
		{
			if (!ShouldUseHttpProvider())
				return null;

			int retryCount = int.Parse(ConfigurationManager.AppSettings["RetryCount"]);
			for (int retry = 1; retry <= retryCount; retry++)
			{
				try
				{
					var dataProvider = new NoSqlAdvProvider();
					var advertisement = dataProvider.GetAdv(id);
					if (advertisement != null)
					{
						SetAdvertisementCache(id, advertisement);
						return advertisement;
					}
				}
				catch
				{
					Thread.Sleep(1000);
					_errors.Enqueue(DateTime.Now);
				}
			}
			return null;
		}

		private bool ShouldUseHttpProvider()
		{
			return _cache.Count() == 0 && GetHourlyErrorCount() < 10;
		}

		private int GetHourlyErrorCount()
		{
			var threshold = DateTime.Now.AddHours(-1);
			while (_errors.Count > 0 && _errors.Peek() < threshold)
			{
				_errors.Dequeue();
			}
			return _errors.Count;
		}

		private Advertisement TryGetAdvertisementFromBackupProvider(string id)
		{
			var advertisement = SQLAdvProvider.GetAdv(id);
			if (advertisement != null)
			{
				SetAdvertisementCache(id, advertisement);
			}
			return advertisement;
		}
	}
}
